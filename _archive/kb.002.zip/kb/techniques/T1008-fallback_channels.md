---
id: T1008
name: Fallback Channels
created: 2017-05-31 21:30:21.689000+00:00
modified: 2025-10-24 17:49:35.854000+00:00
type: attack-pattern
x_mitre_version: 1.1
x_mitre_domains: enterprise-attack
---

## Tactic

- [[command_and_control|Command and Control]]

Adversaries may use fallback or alternate communication channels if the primary channel is compromised or inaccessible in order to maintain reliable command and control and to avoid data transfer thresholds.

## Properties

- id: T1008
- name: Fallback Channels
- created: 2017-05-31 21:30:21.689000+00:00
- modified: 2025-10-24 17:49:35.854000+00:00
- type: attack-pattern
- x_mitre_version: 1.1
- x_mitre_domains: enterprise-attack

## Mitigations

- [[M1031-network_intrusion_prevention|M1031: Network Intrusion Prevention]]

