---
id: T1486
name: Data Encrypted for Impact Mitigation
created: 2019-03-15 14:49:53.983000+00:00
modified: 2025-04-18 17:59:52.091000+00:00
type: course-of-action
---

# Data Encrypted for Impact Mitigation

Consider implementing IT disaster recovery plans that contain procedures for regularly taking and testing data backups that can be used to restore organizational data.(Citation: Ready.gov IT DRP)

In some cases, the means to decrypt files affected by a ransomware campaign is released to the public. Research trusted sources for public releases of decryptor tools/keys to reverse the effects of ransomware.

Identify potentially malicious software and audit and/or block it by using whitelisting(Citation: Beechey 2010) tools, like AppLocker,(Citation: Windows Commands JPCERT)(Citation: NSA MS AppLocker) or Software Restriction Policies(Citation: Corio 2008) where appropriate.(Citation: TechNet Applocker vs SRP)

## Properties

- id: T1486
- name: Data Encrypted for Impact Mitigation
- created: 2019-03-15 14:49:53.983000+00:00
- modified: 2025-04-18 17:59:52.091000+00:00
- type: course-of-action

## Mitigates Techniques


