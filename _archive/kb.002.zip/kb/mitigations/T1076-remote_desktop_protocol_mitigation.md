---
id: T1076
name: Remote Desktop Protocol Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:55.337000+00:00
type: course-of-action
---

# Remote Desktop Protocol Mitigation

Disable the RDP service if it is unnecessary, remove unnecessary accounts and groups from Remote Desktop Users groups, and enable firewall rules to block RDP traffic between network security zones. Audit the Remote Desktop Users group membership regularly. Remove the local Administrators group from the list of groups allowed to log in through RDP. Limit remote user permissions if remote access is necessary. Use remote desktop gateways and multifactor authentication for remote logins. (Citation: Berkley Secure) Do not leave RDP accessible from the internet. Change GPOs to define shorter timeouts sessions and maximum amount of time any single session can be active. Change GPOs to specify the maximum amount of time that a disconnected session stays active on the RD session host server. (Citation: Windows RDP Sessions)

## Properties

- id: T1076
- name: Remote Desktop Protocol Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:55.337000+00:00
- type: course-of-action

## Mitigates Techniques


