---
id: T1153
name: Source Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:55.168000+00:00
type: course-of-action
---

# Source Mitigation

Due to potential legitimate uses of source commands, it's may be difficult to mitigate use of this technique.

## Properties

- id: T1153
- name: Source Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:55.168000+00:00
- type: course-of-action

## Mitigates Techniques


