---
id: T1115
name: Clipboard Data Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:44.345000+00:00
type: course-of-action
---

# Clipboard Data Mitigation

Instead of blocking software based on clipboard capture behavior, identify potentially malicious software that may contain this functionality, and audit and/or block it by using whitelisting (Citation: Beechey 2010) tools, like AppLocker, (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP)

## Properties

- id: T1115
- name: Clipboard Data Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:44.345000+00:00
- type: course-of-action

## Mitigates Techniques


