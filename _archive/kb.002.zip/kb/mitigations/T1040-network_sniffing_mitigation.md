---
id: T1040
name: Network Sniffing Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:53.539000+00:00
type: course-of-action
---

# Network Sniffing Mitigation

Ensure that all wireless traffic is encrypted appropriately. Use Kerberos, SSL, and multifactor authentication wherever possible. Monitor switches and network for span port usage, ARP/DNS poisoning, and router reconfiguration.

Identify and block potentially malicious software that may be used to sniff or analyze network traffic by using whitelisting (Citation: Beechey 2010) tools, like AppLocker, (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP)

## Properties

- id: T1040
- name: Network Sniffing Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:53.539000+00:00
- type: course-of-action

## Mitigates Techniques


