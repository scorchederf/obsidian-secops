---
id: T1019
name: System Firmware Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:46.901000+00:00
type: course-of-action
---

# System Firmware Mitigation

Prevent adversary access to privileged accounts or access necessary to perform this technique. Check the integrity of the existing BIOS or EFI to determine if it is vulnerable to modification. Patch the BIOS and EFI as necessary. Use Trusted Platform Module technology. (Citation: TCG Trusted Platform Module)

## Properties

- id: T1019
- name: System Firmware Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:46.901000+00:00
- type: course-of-action

## Mitigates Techniques


