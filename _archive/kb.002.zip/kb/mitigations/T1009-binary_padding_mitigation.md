---
id: T1009
name: Binary Padding Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:43.580000+00:00
type: course-of-action
---

# Binary Padding Mitigation

Identify potentially malicious software that may be executed from a padded or otherwise obfuscated binary, and audit and/or block it by using whitelisting (Citation: Beechey 2010) tools, like AppLocker, (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP)

## Properties

- id: T1009
- name: Binary Padding Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:43.580000+00:00
- type: course-of-action

## Mitigates Techniques


