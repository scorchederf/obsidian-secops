---
id: T1104
name: Multi-Stage Channels Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:54.629000+00:00
type: course-of-action
---

# Multi-Stage Channels Mitigation

Command and control infrastructure used in a multi-stage channel may be blocked if known ahead of time. If unique signatures are present in the C2 traffic, they could also be used as the basis of identifying and blocking the channel. (Citation: University of Birmingham C2)

## Properties

- id: T1104
- name: Multi-Stage Channels Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:54.629000+00:00
- type: course-of-action

## Mitigates Techniques


