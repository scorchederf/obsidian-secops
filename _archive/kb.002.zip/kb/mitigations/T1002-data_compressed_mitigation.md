---
id: T1002
name: Data Compressed Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:47.085000+00:00
type: course-of-action
---

# Data Compressed Mitigation

Identify unnecessary system utilities, third-party tools, or potentially malicious software that may be used to compress files, and audit and/or block them by using whitelisting (Citation: Beechey 2010) tools, like AppLocker, (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP)

If network intrusion prevention or data loss prevention tools are set to block specific file types from leaving the network over unencrypted channels, then an adversary may move to an encrypted channel.

## Properties

- id: T1002
- name: Data Compressed Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:47.085000+00:00
- type: course-of-action

## Mitigates Techniques


