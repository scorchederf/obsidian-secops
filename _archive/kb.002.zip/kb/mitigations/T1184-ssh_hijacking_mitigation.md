---
id: T1184
name: SSH Hijacking Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:51.888000+00:00
type: course-of-action
---

# SSH Hijacking Mitigation

Ensure SSH key pairs have strong passwords and refrain from using key-store technologies such as ssh-agent unless they are properly protected. Ensure that all private keys are stored securely in locations where only the legitimate owner has access to with strong passwords and are rotated frequently. Ensure proper file permissions are set and harden system to prevent root privilege escalation opportunities. Do not allow remote access via SSH as root or other privileged accounts. Ensure that agent forwarding is disabled on systems that do not explicitly require this feature to prevent misuse. (Citation: Symantec SSH and ssh-agent)

## Properties

- id: T1184
- name: SSH Hijacking Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:51.888000+00:00
- type: course-of-action

## Mitigates Techniques


