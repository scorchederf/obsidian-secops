---
id: T1147
name: Hidden Users Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:42.668000+00:00
type: course-of-action
---

# Hidden Users Mitigation

If the computer is domain joined, then group policy can help restrict the ability to create or hide users. Similarly, preventing the modification of the <code>/Library/Preferences/com.apple.loginwindow</code> <code>Hide500Users</code> value will force all users to be visible.

## Properties

- id: T1147
- name: Hidden Users Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:42.668000+00:00
- type: course-of-action

## Mitigates Techniques


