---
id: T1201
name: Password Policy Discovery Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:53.715000+00:00
type: course-of-action
---

# Password Policy Discovery Mitigation

Mitigating discovery of password policies is not advised since the information is required to be known by systems and users of a network. Ensure password policies are such that they mitigate brute force attacks yet will not give an adversary an information advantage because the policies are too light. Active Directory is a common way to set and enforce password policies throughout an enterprise network. (Citation: Microsoft Password Complexity)

## Properties

- id: T1201
- name: Password Policy Discovery Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:53.715000+00:00
- type: course-of-action

## Mitigates Techniques


