---
id: T1109
name: Component Firmware Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:57.839000+00:00
type: course-of-action
---

# Component Firmware Mitigation

Prevent adversary access to privileged accounts or access necessary to perform this technique.

Consider removing and replacing system components suspected of being compromised.

## Properties

- id: T1109
- name: Component Firmware Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:57.839000+00:00
- type: course-of-action

## Mitigates Techniques


