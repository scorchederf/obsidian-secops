---
id: T1102
name: Web Service Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:53.168000+00:00
type: course-of-action
---

# Web Service Mitigation

Firewalls and Web proxies can be used to enforce external network communication policy. It may be difficult for an organization to block particular services because so many of them are commonly used during the course of business.

Network intrusion detection and prevention systems that use network signatures to identify traffic for specific adversary malware can be used to mitigate activity at the network level. Signatures are often for unique indicators within protocols and may be based on the specific protocol or encoded commands used by a particular adversary or tool, and will likely be different across various malware families and versions. Adversaries will likely change tool C2 signatures over time or construct protocols in such a way as to avoid detection by common defensive tools. (Citation: University of Birmingham C2)

## Properties

- id: T1102
- name: Web Service Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:53.168000+00:00
- type: course-of-action

## Mitigates Techniques


