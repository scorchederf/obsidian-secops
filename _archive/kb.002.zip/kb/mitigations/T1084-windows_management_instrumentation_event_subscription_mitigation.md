---
id: T1084
name: Windows Management Instrumentation Event Subscription Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:41.767000+00:00
type: course-of-action
---

# Windows Management Instrumentation Event Subscription Mitigation

Disabling WMI services may cause system instability and should be evaluated to assess the impact to a network. By default, only administrators are allowed to connect remotely using WMI; restrict other users that are allowed to connect, or disallow all users from connecting remotely to WMI. Prevent credential overlap across systems of administrator and privileged accounts. (Citation: FireEye WMI 2015)

## Properties

- id: T1084
- name: Windows Management Instrumentation Event Subscription Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:41.767000+00:00
- type: course-of-action

## Mitigates Techniques


