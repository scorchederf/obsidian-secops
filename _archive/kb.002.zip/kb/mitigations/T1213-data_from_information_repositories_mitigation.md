---
id: T1213
name: Data from Information Repositories Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:42.836000+00:00
type: course-of-action
---

# Data from Information Repositories Mitigation

To mitigate adversary access to information repositories for collection:

* Develop and publish policies that define acceptable information to be stored
* Appropriate implementation of access control mechanisms that include both authentication and appropriate authorization
* Enforce the principle of least-privilege
* Periodic privilege review of accounts
* Mitigate access to [Valid Accounts](https://attack.mitre.org/techniques/T1078) that may be used to access repositories

## Properties

- id: T1213
- name: Data from Information Repositories Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:42.836000+00:00
- type: course-of-action

## Mitigates Techniques


