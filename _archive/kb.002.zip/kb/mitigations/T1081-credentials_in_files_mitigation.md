---
id: T1081
name: Credentials in Files Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:40.502000+00:00
type: course-of-action
---

# Credentials in Files Mitigation

Establish an organizational policy that prohibits password storage in files. Ensure that developers and system administrators are aware of the risk associated with having plaintext passwords in software configuration files that may be left on endpoint systems or servers. Preemptively search for files containing passwords and remove when found. Restrict file shares to specific directories with access only to necessary users. Remove vulnerable Group Policy Preferences. (Citation: Microsoft MS14-025)

## Properties

- id: T1081
- name: Credentials in Files Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:40.502000+00:00
- type: course-of-action

## Mitigates Techniques


