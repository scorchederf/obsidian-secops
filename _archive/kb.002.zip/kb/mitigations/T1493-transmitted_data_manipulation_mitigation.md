---
id: T1493
name: Transmitted Data Manipulation Mitigation
created: 2019-04-24 17:03:39.689000+00:00
modified: 2025-04-18 17:59:46.349000+00:00
type: course-of-action
---

# Transmitted Data Manipulation Mitigation

Identify critical business and system processes that may be targeted by adversaries and work to secure communications related to those processes against tampering. Encrypt all important data flows to reduce the impact of tailored modifications on data in transit.

## Properties

- id: T1493
- name: Transmitted Data Manipulation Mitigation
- created: 2019-04-24 17:03:39.689000+00:00
- modified: 2025-04-18 17:59:46.349000+00:00
- type: course-of-action

## Mitigates Techniques


