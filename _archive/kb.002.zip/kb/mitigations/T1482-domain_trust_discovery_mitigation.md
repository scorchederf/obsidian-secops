---
id: T1482
name: Domain Trust Discovery Mitigation
created: 2019-02-15 13:04:25.150000+00:00
modified: 2025-04-18 17:59:43.219000+00:00
type: course-of-action
---

# Domain Trust Discovery Mitigation

Map the trusts within existing domains/forests and keep trust relationships to a minimum. Employ network segmentation for sensitive domains.(Citation: Harmj0y Domain Trusts)

## Properties

- id: T1482
- name: Domain Trust Discovery Mitigation
- created: 2019-02-15 13:04:25.150000+00:00
- modified: 2025-04-18 17:59:43.219000+00:00
- type: course-of-action

## Mitigates Techniques


