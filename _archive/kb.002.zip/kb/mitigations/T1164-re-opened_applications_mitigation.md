---
id: T1164
name: Re-opened Applications Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:56.953000+00:00
type: course-of-action
---

# Re-opened Applications Mitigation

Holding the Shift key while logging in prevents apps from opening automatically (Citation: Re-Open windows on Mac). This feature can be disabled entirely with the following terminal command: <code>defaults write -g ApplePersistence -bool no</code>.

## Properties

- id: T1164
- name: Re-opened Applications Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:56.953000+00:00
- type: course-of-action

## Mitigates Techniques


