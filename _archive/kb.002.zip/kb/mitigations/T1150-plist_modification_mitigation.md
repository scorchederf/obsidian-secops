---
id: T1150
name: Plist Modification Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:47.826000+00:00
type: course-of-action
---

# Plist Modification Mitigation

Prevent plist files from being modified by users by making them read-only.

## Properties

- id: T1150
- name: Plist Modification Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:47.826000+00:00
- type: course-of-action

## Mitigates Techniques


