---
id: T1123
name: Audio Capture Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:43.746000+00:00
type: course-of-action
---

# Audio Capture Mitigation

Mitigating this technique specifically may be difficult as it requires fine-grained API control. Efforts should be focused on preventing unwanted or unknown code from executing on a system.

Identify and block potentially malicious software that may be used to record audio by using whitelisting (Citation: Beechey 2010) tools, like AppLocker, (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP)

## Properties

- id: T1123
- name: Audio Capture Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:43.746000+00:00
- type: course-of-action

## Mitigates Techniques


