---
id: T1128
name: Netsh Helper DLL Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:57.124000+00:00
type: course-of-action
---

# Netsh Helper DLL Mitigation

Identify and block potentially malicious software that may persist in this manner by using whitelisting (Citation: Beechey 2010) tools capable of monitoring DLL loads by Windows utilities like AppLocker. (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker)

## Properties

- id: T1128
- name: Netsh Helper DLL Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:57.124000+00:00
- type: course-of-action

## Mitigates Techniques


