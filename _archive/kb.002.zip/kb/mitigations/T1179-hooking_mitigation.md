---
id: T1179
name: Hooking Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 18:00:00.204000+00:00
type: course-of-action
---

# Hooking Mitigation

This type of attack technique cannot be easily mitigated with preventive controls since it is based on the abuse of operating system design features. For example, mitigating all hooking will likely have unintended side effects, such as preventing legitimate software (i.e., security products) from operating properly. Efforts should be focused on preventing adversary tools from running earlier in the chain of activity and on identifying subsequent malicious behavior.

## Properties

- id: T1179
- name: Hooking Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 18:00:00.204000+00:00
- type: course-of-action

## Mitigates Techniques


