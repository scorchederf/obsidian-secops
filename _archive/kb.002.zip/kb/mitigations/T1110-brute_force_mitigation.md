---
id: T1110
name: Brute Force Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:53.874000+00:00
type: course-of-action
---

# Brute Force Mitigation

Set account lockout policies after a certain number of failed login attempts to prevent passwords from being guessed. 
Too strict a policy can create a denial of service condition and render environments un-usable, with all accounts being locked-out permanently. Use multifactor authentication. Follow best practices for mitigating access to [Valid Accounts](https://attack.mitre.org/techniques/T1078)

Refer to NIST guidelines when creating passwords.(Citation: NIST 800-63-3)

Where possible, also enable multi factor authentication on external facing services.

## Properties

- id: T1110
- name: Brute Force Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:53.874000+00:00
- type: course-of-action

## Mitigates Techniques


