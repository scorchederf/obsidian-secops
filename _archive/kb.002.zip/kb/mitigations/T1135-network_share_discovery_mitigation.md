---
id: T1135
name: Network Share Discovery Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:45.639000+00:00
type: course-of-action
---

# Network Share Discovery Mitigation

Identify unnecessary system utilities or potentially malicious software that may be used to acquire network share information, and audit and/or block them by using whitelisting (Citation: Beechey 2010) tools, like AppLocker, (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP)

## Properties

- id: T1135
- name: Network Share Discovery Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:45.639000+00:00
- type: course-of-action

## Mitigates Techniques


