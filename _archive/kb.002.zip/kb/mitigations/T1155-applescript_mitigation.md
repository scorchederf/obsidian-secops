---
id: T1155
name: AppleScript Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:45.279000+00:00
type: course-of-action
---

# AppleScript Mitigation

Require that all AppleScript be signed by a trusted developer ID before being executed - this will prevent random AppleScript code from executing  (Citation: applescript signing). This subjects AppleScript code to the same scrutiny as other .app files passing through Gatekeeper.

## Properties

- id: T1155
- name: AppleScript Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:45.279000+00:00
- type: course-of-action

## Mitigates Techniques


