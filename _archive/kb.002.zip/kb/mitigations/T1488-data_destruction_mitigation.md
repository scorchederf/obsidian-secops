---
id: T1488
name: Data Destruction Mitigation
created: 2019-03-14 20:17:16.234000+00:00
modified: 2025-04-18 17:59:41.583000+00:00
type: course-of-action
---

# Data Destruction Mitigation

Consider implementing IT disaster recovery plans that contain procedures for taking regular data backups that can be used to restore organizational data.(Citation: Ready.gov IT DRP) Ensure backups are stored off system and is protected from common methods adversaries may use to gain access and destroy the backups to prevent recovery.

Identify potentially malicious software and audit and/or block it by using whitelisting(Citation: Beechey 2010) tools, like AppLocker,(Citation: Windows Commands JPCERT)(Citation: NSA MS AppLocker) or Software Restriction Policies(Citation: Corio 2008) where appropriate.(Citation: TechNet Applocker vs SRP)

## Properties

- id: T1488
- name: Data Destruction Mitigation
- created: 2019-03-14 20:17:16.234000+00:00
- modified: 2025-04-18 17:59:41.583000+00:00
- type: course-of-action

## Mitigates Techniques


