---
id: T1171
name: LLMNR/NBT-NS Poisoning Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:55.532000+00:00
type: course-of-action
---

# LLMNR/NBT-NS Poisoning Mitigation

Disable LLMNR and NetBIOS in local computer security settings or by group policy if they are not needed within an environment. (Citation: ADSecurity Windows Secure Baseline)

Use host-based security software to block LLMNR/NetBIOS traffic. Enabling SMB Signing can stop NTLMv2 relay attacks.(Citation: byt3bl33d3r NTLM Relaying)(Citation: Secure Ideas SMB Relay)(Citation: Microsoft SMB Packet Signing)

## Properties

- id: T1171
- name: LLMNR/NBT-NS Poisoning Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:55.532000+00:00
- type: course-of-action

## Mitigates Techniques


