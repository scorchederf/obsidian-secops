---
id: T1070
name: Indicator Removal on Host Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:58.214000+00:00
type: course-of-action
---

# Indicator Removal on Host Mitigation

Automatically forward events to a log server or data repository to prevent conditions in which the adversary can locate and manipulate data on the local system. When possible, minimize time delay on event reporting to avoid prolonged storage on the local system. Protect generated event files that are stored locally with proper permissions and authentication and limit opportunities for adversaries to increase privileges by preventing Privilege Escalation opportunities. Obfuscate/encrypt event files locally and in transit to avoid giving feedback to an adversary.

## Properties

- id: T1070
- name: Indicator Removal on Host Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:58.214000+00:00
- type: course-of-action

## Mitigates Techniques


