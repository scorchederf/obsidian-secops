---
id: T1028
name: Windows Remote Management Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:51.358000+00:00
type: course-of-action
---

# Windows Remote Management Mitigation

Disable the WinRM service. If the service is necessary, lock down critical enclaves with separate WinRM infrastructure, accounts, and permissions. Follow WinRM best practices on configuration of authentication methods and use of host firewalls to restrict WinRM access to allow communication only to/from specific devices. (Citation: NSA Spotting)

## Properties

- id: T1028
- name: Windows Remote Management Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:51.358000+00:00
- type: course-of-action

## Mitigates Techniques


