---
id: T1117
name: Regsvr32 Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:42.490000+00:00
type: course-of-action
---

# Regsvr32 Mitigation

Microsoft's Enhanced Mitigation Experience Toolkit (EMET) Attack Surface Reduction (ASR) feature can be used to block regsvr32.exe from being used to bypass whitelisting. (Citation: Secure Host Baseline EMET)

## Properties

- id: T1117
- name: Regsvr32 Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:42.490000+00:00
- type: course-of-action

## Mitigates Techniques


