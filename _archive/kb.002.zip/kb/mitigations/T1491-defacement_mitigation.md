---
id: T1491
name: Defacement Mitigation
created: 2019-04-08 17:51:41.510000+00:00
modified: 2025-04-18 17:59:56.773000+00:00
type: course-of-action
---

# Defacement Mitigation

Implementing best practices for websites such as defending against [Exploit Public-Facing Application](https://attack.mitre.org/techniques/T1190) (Citation: OWASP Top 10 2017). Consider implementing IT disaster recovery plans that contain procedures for taking regular data backups that can be used to restore organizational data. (Ready.gov IT DRP) Ensure backups are stored off system and is protected from common methods adversaries may use to gain access and destroy the backups to prevent recovery.

## Properties

- id: T1491
- name: Defacement Mitigation
- created: 2019-04-08 17:51:41.510000+00:00
- modified: 2025-04-18 17:59:56.773000+00:00
- type: course-of-action

## Mitigates Techniques


