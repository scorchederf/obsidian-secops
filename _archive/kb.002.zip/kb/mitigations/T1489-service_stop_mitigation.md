---
id: T1489
name: Service Stop Mitigation
created: 2019-04-24 17:01:10.433000+00:00
modified: 2025-04-18 17:59:51.716000+00:00
type: course-of-action
---

# Service Stop Mitigation

Ensure proper process, registry, and file permissions are in place to inhibit adversaries from disabling or interfering with critical services. Limit privileges of user accounts and groups so that only authorized administrators can interact with service changes and service configurations. Harden systems used to serve critical network, business, and communications functions. Operate intrusion detection, analysis, and response systems on a separate network from the production environment to lessen the chances that an adversary can see and interfere with critical response functions.

## Properties

- id: T1489
- name: Service Stop Mitigation
- created: 2019-04-24 17:01:10.433000+00:00
- modified: 2025-04-18 17:59:51.716000+00:00
- type: course-of-action

## Mitigates Techniques


