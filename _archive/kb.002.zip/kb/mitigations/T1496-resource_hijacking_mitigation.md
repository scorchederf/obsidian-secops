---
id: T1496
name: Resource Hijacking Mitigation
created: 2019-04-24 16:59:33.603000+00:00
modified: 2025-04-18 17:59:53.345000+00:00
type: course-of-action
---

# Resource Hijacking Mitigation

Identify potentially malicious software and audit and/or block it by using whitelisting(Citation: Beechey 2010) tools, like AppLocker,(Citation: Windows Commands JPCERT)(Citation: NSA MS AppLocker) or Software Restriction Policies(Citation: Corio 2008) where appropriate.(Citation: TechNet Applocker vs SRP)

## Properties

- id: T1496
- name: Resource Hijacking Mitigation
- created: 2019-04-24 16:59:33.603000+00:00
- modified: 2025-04-18 17:59:53.345000+00:00
- type: course-of-action

## Mitigates Techniques


