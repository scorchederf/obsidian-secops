---
id: T1183
name: Image File Execution Options Injection Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:48.585000+00:00
type: course-of-action
---

# Image File Execution Options Injection Mitigation

This type of attack technique cannot be easily mitigated with preventive controls since it is based on the abuse of operating system design features. For example, mitigating all IFEO will likely have unintended side effects, such as preventing legitimate software (i.e., security products) from operating properly. (Citation: Microsoft IFEOorMalware July 2015) Efforts should be focused on preventing adversary tools from running earlier in the chain of activity and on identifying subsequent malicious behavior.

Identify and block potentially malicious software that may be executed through IFEO by using whitelisting (Citation: Beechey 2010) tools, like AppLocker, (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) that are capable of auditing and/or blocking unknown executables.

## Properties

- id: T1183
- name: Image File Execution Options Injection Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:48.585000+00:00
- type: course-of-action

## Mitigates Techniques


