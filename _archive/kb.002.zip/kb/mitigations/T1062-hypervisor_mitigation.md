---
id: T1062
name: Hypervisor Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:47.647000+00:00
type: course-of-action
---

# Hypervisor Mitigation

Prevent adversary access to privileged accounts necessary to install a hypervisor.

## Properties

- id: T1062
- name: Hypervisor Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:47.647000+00:00
- type: course-of-action

## Mitigates Techniques


