---
id: T1077
name: Windows Admin Shares Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:48.056000+00:00
type: course-of-action
---

# Windows Admin Shares Mitigation

Do not reuse local administrator account passwords across systems. Ensure password complexity and uniqueness such that the passwords cannot be cracked or guessed. Deny remote use of local admin credentials to log into systems. Do not allow domain user accounts to be in the local Administrators group multiple systems.

Identify unnecessary system utilities or potentially malicious software that may be used to leverage SMB and the Windows admin shares, and audit and/or block them by using whitelisting (Citation: Beechey 2010) tools, like AppLocker, (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP)

## Properties

- id: T1077
- name: Windows Admin Shares Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:48.056000+00:00
- type: course-of-action

## Mitigates Techniques


