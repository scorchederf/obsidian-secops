---
id: T1144
name: Gatekeeper Bypass Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:44.547000+00:00
type: course-of-action
---

# Gatekeeper Bypass Mitigation

Other tools should be used to supplement Gatekeeper's functionality. Additionally, system settings can prevent applications from running that haven't been downloaded through the Apple Store which can help mitigate some of these issues.

## Properties

- id: T1144
- name: Gatekeeper Bypass Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:44.547000+00:00
- type: course-of-action

## Mitigates Techniques


