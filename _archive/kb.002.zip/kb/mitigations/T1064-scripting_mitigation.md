---
id: T1064
name: Scripting Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:56.241000+00:00
type: course-of-action
---

# Scripting Mitigation

Turn off unused features or restrict access to scripting engines such as VBScript or scriptable administration frameworks such as PowerShell.

Configure Office security settings enable Protected View, to execute within a sandbox environment, and to block macros through Group Policy. (Citation: Microsoft Block Office Macros) Other types of virtualization and application microsegmentation may also mitigate the impact of compromise. The risks of additional exploits and weaknesses in implementation may still exist. (Citation: Ars Technica Pwn2Own 2017 VM Escape)

## Properties

- id: T1064
- name: Scripting Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:56.241000+00:00
- type: course-of-action

## Mitigates Techniques


