---
id: T1149
name: LC_MAIN Hijacking Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:58.383000+00:00
type: course-of-action
---

# LC_MAIN Hijacking Mitigation

Enforce valid digital signatures for signed code on all applications and only trust applications with signatures from trusted parties.

## Properties

- id: T1149
- name: LC_MAIN Hijacking Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:58.383000+00:00
- type: course-of-action

## Mitigates Techniques


