---
id: T1162
name: Login Item Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:41.043000+00:00
type: course-of-action
---

# Login Item Mitigation

Restrict users from being able to create their own login items. Additionally, holding the shift key during login prevents apps from opening automatically (Citation: Re-Open windows on Mac).

## Properties

- id: T1162
- name: Login Item Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:41.043000+00:00
- type: course-of-action

## Mitigates Techniques


