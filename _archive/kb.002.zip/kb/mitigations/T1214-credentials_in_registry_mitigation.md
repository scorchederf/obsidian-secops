---
id: T1214
name: Credentials in Registry Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:52.794000+00:00
type: course-of-action
---

# Credentials in Registry Mitigation

Do not store credentials within the Registry. Proactively search for credentials within Registry keys and attempt to remediate the risk. If necessary software must store credentials, then ensure those accounts have limited permissions so they cannot be abused if obtained by an adversary.

## Properties

- id: T1214
- name: Credentials in Registry Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:52.794000+00:00
- type: course-of-action

## Mitigates Techniques


