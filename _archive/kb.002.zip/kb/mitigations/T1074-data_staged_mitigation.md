---
id: T1074
name: Data Staged Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:52.263000+00:00
type: course-of-action
---

# Data Staged Mitigation

Identify system utilities, remote access or third-party tools, users or potentially malicious software that may be used to store compressed or encrypted data in a publicly writeable directory, central location, or commonly used staging directories (e.g. recycle bin) that is indicative of non-standard behavior, and audit and/or block them by using file integrity monitoring tools where appropriate. Consider applying data size limits or blocking file writes of common compression and encryption utilities such as 7zip, RAR, ZIP, or zlib on frequently used staging directories or central locations and monitor attempted violations of those restrictions.

## Properties

- id: T1074
- name: Data Staged Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:52.263000+00:00
- type: course-of-action

## Mitigates Techniques


