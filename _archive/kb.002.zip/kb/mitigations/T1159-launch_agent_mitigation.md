---
id: T1159
name: Launch Agent Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:42.298000+00:00
type: course-of-action
---

# Launch Agent Mitigation

Restrict user's abilities to create Launch Agents with group policy.

## Properties

- id: T1159
- name: Launch Agent Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:42.298000+00:00
- type: course-of-action

## Mitigates Techniques


