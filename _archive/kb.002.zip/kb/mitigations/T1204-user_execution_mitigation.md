---
id: T1204
name: User Execution Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:55.719000+00:00
type: course-of-action
---

# User Execution Mitigation

Use user training as a way to bring awareness to common phishing and spearphishing techniques and how to raise suspicion for potentially malicious events. Application whitelisting may be able to prevent the running of executables masquerading as other files.

If a link is being visited by a user, block unknown or unused files in transit by default that should not be downloaded or by policy from suspicious sites as a best practice to prevent some vectors, such as .scr, .exe, .lnk, .pif, .cpl, etc. Some download scanning devices can open and analyze compressed and encrypted formats, such as zip and RAR that may be used to conceal malicious files in [Obfuscated Files or Information](https://attack.mitre.org/techniques/T1027).

If a link is being visited by a user, network intrusion prevention systems and systems designed to scan and remove malicious downloads can be used to block activity. Solutions can be signature and behavior based, but adversaries may construct files in a way to avoid these systems.

## Properties

- id: T1204
- name: User Execution Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:55.719000+00:00
- type: course-of-action

## Mitigates Techniques


