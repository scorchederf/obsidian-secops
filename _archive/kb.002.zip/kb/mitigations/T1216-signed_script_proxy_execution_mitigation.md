---
id: T1216
name: Signed Script Proxy Execution Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:54.428000+00:00
type: course-of-action
---

# Signed Script Proxy Execution Mitigation

Certain signed scripts that can be used to execute other programs may not be necessary within a given environment. Use application whitelisting configured to block execution of these scripts if they are not required for a given system or network to prevent potential misuse by adversaries.

## Properties

- id: T1216
- name: Signed Script Proxy Execution Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:54.428000+00:00
- type: course-of-action

## Mitigates Techniques


