---
id: T1494
name: Runtime Data Manipulation Mitigation
created: 2019-04-12 14:59:36.522000+00:00
modified: 2025-04-18 17:59:48.395000+00:00
type: course-of-action
---

# Runtime Data Manipulation Mitigation

Identify critical business and system processes that may be targeted by adversaries and work to secure those systems against tampering. Prevent critical business and system processes from being replaced, overwritten, or reconfigured to load potentially malicious code. Identify potentially malicious software and audit and/or block it by using whitelisting(Citation: Beechey 2010) tools, like AppLocker,(Citation: Windows Commands JPCERT)(Citation: NSA MS AppLocker) or Software Restriction Policies(Citation: Corio 2008) where appropriate.(Citation: TechNet Applocker vs SRP)

## Properties

- id: T1494
- name: Runtime Data Manipulation Mitigation
- created: 2019-04-12 14:59:36.522000+00:00
- modified: 2025-04-18 17:59:48.395000+00:00
- type: course-of-action

## Mitigates Techniques


