---
id: T1099
name: Timestomp Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:56.408000+00:00
type: course-of-action
---

# Timestomp Mitigation

Mitigation of timestomping specifically is likely difficult. Efforts should be focused on preventing potentially malicious software from running. Identify and block potentially malicious software that may contain functionality to perform timestomping by using whitelisting (Citation: Beechey 2010) tools like AppLocker (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP)

## Properties

- id: T1099
- name: Timestomp Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:56.408000+00:00
- type: course-of-action

## Mitigates Techniques


