---
id: T1066
name: Indicator Removal from Tools Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:54.080000+00:00
type: course-of-action
---

# Indicator Removal from Tools Mitigation

Mitigation is difficult in instances like this because the adversary may have access to the system through another channel and can learn what techniques or tools are blocked by resident defenses. Exercising best practices with configuration and security as well as ensuring that proper process is followed during investigation of potential compromise is essential to detecting a larger intrusion through discrete alerts.

Identify and block potentially malicious software that may be used by an adversary by using whitelisting (Citation: Beechey 2010) tools like AppLocker (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP)

## Properties

- id: T1066
- name: Indicator Removal from Tools Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:54.080000+00:00
- type: course-of-action

## Mitigates Techniques


