---
id: T1089
name: Disabling Security Tools Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:50.085000+00:00
type: course-of-action
---

# Disabling Security Tools Mitigation

Ensure proper process, registry, and file permissions are in place to prevent adversaries from disabling or interfering with security services.

## Properties

- id: T1089
- name: Disabling Security Tools Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:50.085000+00:00
- type: course-of-action

## Mitigates Techniques


