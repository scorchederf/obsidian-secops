---
id: T1217
name: Browser Bookmark Discovery Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:44.887000+00:00
type: course-of-action
---

# Browser Bookmark Discovery Mitigation

File system activity is a common part of an operating system, so it is unlikely that mitigation would be appropriate for this technique. For example, mitigating accesses to browser bookmark files will likely have unintended side effects such as preventing legitimate software from operating properly. Efforts should be focused on preventing adversary tools from running earlier in the chain of activity and on identification of subsequent malicious behavior. It may still be beneficial to identify and block unnecessary system utilities or potentially malicious software by using whitelisting (Citation: Beechey 2010) tools, like AppLocker, (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP)

## Properties

- id: T1217
- name: Browser Bookmark Discovery Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:44.887000+00:00
- type: course-of-action

## Mitigates Techniques


