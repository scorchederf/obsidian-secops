---
id: T1004
name: Winlogon Helper DLL Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:48.229000+00:00
type: course-of-action
---

# Winlogon Helper DLL Mitigation

Limit the privileges of user accounts so that only authorized administrators can perform Winlogon helper changes.

Identify and block potentially malicious software that may be executed through the Winlogon helper process by using whitelisting (Citation: Beechey 2010) tools like AppLocker (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) that are capable of auditing and/or blocking unknown DLLs.

## Properties

- id: T1004
- name: Winlogon Helper DLL Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:48.229000+00:00
- type: course-of-action

## Mitigates Techniques


