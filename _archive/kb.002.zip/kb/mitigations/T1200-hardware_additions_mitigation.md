---
id: T1200
name: Hardware Additions Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:55.894000+00:00
type: course-of-action
---

# Hardware Additions Mitigation

Establish network access control policies, such as using device certificates and the 802.1x standard. (Citation: Wikipedia 802.1x) Restrict use of DHCP to registered devices to prevent unregistered devices from communicating with trusted systems. 

Block unknown devices and accessories by endpoint security configuration and monitoring agent.

## Properties

- id: T1200
- name: Hardware Additions Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:55.894000+00:00
- type: course-of-action

## Mitigates Techniques


