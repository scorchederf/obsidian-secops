---
id: T1495
name: Firmware Corruption Mitigation
created: 2019-04-26 19:30:33.607000+00:00
modified: 2025-04-18 17:59:58.741000+00:00
type: course-of-action
---

# Firmware Corruption Mitigation

Prevent adversary access to privileged accounts or access necessary to perform this technique. Check the integrity of the existing BIOS and device firmware to determine if it is vulnerable to modification. Patch the BIOS and other firmware as necessary to prevent successful use of known vulnerabilities. 

## Properties

- id: T1495
- name: Firmware Corruption Mitigation
- created: 2019-04-26 19:30:33.607000+00:00
- modified: 2025-04-18 17:59:58.741000+00:00
- type: course-of-action

## Mitigates Techniques


