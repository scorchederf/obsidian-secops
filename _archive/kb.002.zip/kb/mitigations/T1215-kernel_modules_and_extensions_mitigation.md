---
id: T1215
name: Kernel Modules and Extensions Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:52.625000+00:00
type: course-of-action
---

# Kernel Modules and Extensions Mitigation

Common tools for detecting Linux rootkits include: rkhunter (Citation: SourceForge rkhunter), chrootkit (Citation: Chkrootkit Main), although rootkits may be designed to evade certain detection tools.

LKMs and Kernel extensions require root level permissions to be installed. Limit access to the root account and prevent users from loading kernel modules and extensions through proper privilege separation and limiting Privilege Escalation opportunities.

Application whitelisting and software restriction tools, such as SELinux, can also aide in restricting kernel module loading. (Citation: Kernel.org Restrict Kernel Module)

## Properties

- id: T1215
- name: Kernel Modules and Extensions Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:52.625000+00:00
- type: course-of-action

## Mitigates Techniques


