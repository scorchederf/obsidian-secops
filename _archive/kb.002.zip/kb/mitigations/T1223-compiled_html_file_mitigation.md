---
id: T1223
name: Compiled HTML File Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:41.389000+00:00
type: course-of-action
---

# Compiled HTML File Mitigation

Consider blocking download/transfer and execution of potentially uncommon file types known to be used in adversary campaigns, such as CHM files. (Citation: PaloAlto Preventing Opportunistic Attacks Apr 2016) Also consider using application whitelisting to prevent execution of hh.exe if it is not required for a given system or network to prevent potential misuse by adversaries.

## Properties

- id: T1223
- name: Compiled HTML File Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:41.389000+00:00
- type: course-of-action

## Mitigates Techniques


