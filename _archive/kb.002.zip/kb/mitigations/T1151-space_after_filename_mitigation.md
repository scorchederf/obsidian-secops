---
id: T1151
name: Space after Filename Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:40.127000+00:00
type: course-of-action
---

# Space after Filename Mitigation

Prevent files from having a trailing space after the extension.

## Properties

- id: T1151
- name: Space after Filename Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:40.127000+00:00
- type: course-of-action

## Mitigates Techniques


