---
id: T1172
name: Domain Fronting Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:57.301000+00:00
type: course-of-action
---

# Domain Fronting Mitigation

If it is possible to inspect HTTPS traffic, the captures can be analyzed for connections that appear to be Domain Fronting.

In order to use domain fronting, attackers will likely need to deploy additional tools to compromised systems. (Citation: FireEye APT29 Domain Fronting With TOR March 2017) (Citation: Mandiant No Easy Breach) It may be possible to detect or prevent the installation of these tools with Host-based solutions.

## Properties

- id: T1172
- name: Domain Fronting Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:57.301000+00:00
- type: course-of-action

## Mitigates Techniques


