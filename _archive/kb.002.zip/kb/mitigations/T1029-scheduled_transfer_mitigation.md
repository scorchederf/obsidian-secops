---
id: T1029
name: Scheduled Transfer Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:44.718000+00:00
type: course-of-action
---

# Scheduled Transfer Mitigation

Network intrusion detection and prevention systems that use network signatures to identify traffic for specific adversary command and control infrastructure and malware can be used to mitigate activity at the network level. Signatures are often for unique indicators within protocols and may be based on the specific obfuscation technique used by a particular adversary or tool, and will likely be different across various malware families and versions. Adversaries will likely change tool command and control signatures over time or construct protocols in such a way to avoid detection by common defensive tools. (Citation: University of Birmingham C2)

## Properties

- id: T1029
- name: Scheduled Transfer Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:44.718000+00:00
- type: course-of-action

## Mitigates Techniques


