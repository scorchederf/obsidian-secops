---
id: T1188
name: Multi-hop Proxy Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:58.906000+00:00
type: course-of-action
---

# Multi-hop Proxy Mitigation

Traffic to known anonymity networks and C2 infrastructure can be blocked through the use of network black and white lists. It should be noted that this kind of blocking may be circumvented by other techniques like [Domain Fronting](https://attack.mitre.org/techniques/T1172).

## Properties

- id: T1188
- name: Multi-hop Proxy Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:58.906000+00:00
- type: course-of-action

## Mitigates Techniques


