---
id: T1166
name: Setuid and Setgid Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:41.210000+00:00
type: course-of-action
---

# Setuid and Setgid Mitigation

Applications with known vulnerabilities or known shell escapes should not have the setuid or setgid bits set to reduce potential damage if an application is compromised. Additionally, the number of programs with setuid or setgid bits set should be minimized across a system.

## Properties

- id: T1166
- name: Setuid and Setgid Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:41.210000+00:00
- type: course-of-action

## Mitigates Techniques


