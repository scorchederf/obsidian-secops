---
id: T1146
name: Clear Command History Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:51.180000+00:00
type: course-of-action
---

# Clear Command History Mitigation

Preventing users from deleting or writing to certain files can stop adversaries from maliciously altering their <code>~/.bash_history</code> files. Additionally, making these environment variables readonly can make sure that the history is preserved   (Citation: Securing bash history).

## Properties

- id: T1146
- name: Clear Command History Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:51.180000+00:00
- type: course-of-action

## Mitigates Techniques


