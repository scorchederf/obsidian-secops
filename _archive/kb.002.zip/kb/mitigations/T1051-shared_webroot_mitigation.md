---
id: T1051
name: Shared Webroot Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:52.427000+00:00
type: course-of-action
---

# Shared Webroot Mitigation

Networks that allow for open development and testing of Web content and allow users to set up their own Web servers on the enterprise network may be particularly vulnerable if the systems and Web servers are not properly secured to limit privileged account use, unauthenticated network share access, and network/system isolation.

Ensure proper permissions on directories that are accessible through a Web server. Disallow remote access to the webroot or other directories used to serve Web content. Disable execution on directories within the webroot. Ensure that permissions of the Web server process are only what is required by not using built-in accounts; instead, create specific accounts to limit unnecessary access or permissions overlap across multiple systems. (Citation: acunetix Server Secuirty) (Citation: NIST Server Security July 2008)

## Properties

- id: T1051
- name: Shared Webroot Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:52.427000+00:00
- type: course-of-action

## Mitigates Techniques


