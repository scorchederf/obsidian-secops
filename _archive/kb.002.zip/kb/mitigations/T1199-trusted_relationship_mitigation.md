---
id: T1199
name: Trusted Relationship Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:59.440000+00:00
type: course-of-action
---

# Trusted Relationship Mitigation

Network segmentation can be used to isolate infrastructure components that do not require broad network access. Properly manage accounts and permissions used by parties in trusted relationships to minimize potential abuse by the party and if the party is compromised by an adversary. Vet the security policies and procedures of organizations that are contracted for work that require privileged access to network resources.

## Properties

- id: T1199
- name: Trusted Relationship Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:59.440000+00:00
- type: course-of-action

## Mitigates Techniques


