---
id: T1107
name: File Deletion Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:48.941000+00:00
type: course-of-action
---

# File Deletion Mitigation

Identify unnecessary system utilities, third-party tools, or potentially malicious software that may be used to delete files, and audit and/or block them by using whitelisting (Citation: Beechey 2010) tools like AppLocker (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP)

## Properties

- id: T1107
- name: File Deletion Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:48.941000+00:00
- type: course-of-action

## Mitigates Techniques


