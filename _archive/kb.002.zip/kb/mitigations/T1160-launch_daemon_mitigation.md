---
id: T1160
name: Launch Daemon Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:51.544000+00:00
type: course-of-action
---

# Launch Daemon Mitigation

Limit privileges of user accounts and remediate Privilege Escalation vectors so only authorized administrators can create new Launch Daemons.

## Properties

- id: T1160
- name: Launch Daemon Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:51.544000+00:00
- type: course-of-action

## Mitigates Techniques


