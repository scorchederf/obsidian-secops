---
id: T1202
name: Indirect Command Execution Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:45.448000+00:00
type: course-of-action
---

# Indirect Command Execution Mitigation

Identify or block potentially malicious software that may contain abusive functionality by using whitelisting (Citation: Beechey 2010) tools, like AppLocker, (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP). These mechanisms can also be used to disable and/or limit user access to Windows utilities and file types/locations used to invoke malicious execution.(Citation: SpectorOPs SettingContent-ms Jun 2018)

## Properties

- id: T1202
- name: Indirect Command Execution Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:45.448000+00:00
- type: course-of-action

## Mitigates Techniques


