---
id: T1148
name: HISTCONTROL Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:40.291000+00:00
type: course-of-action
---

# HISTCONTROL Mitigation

Prevent users from changing the <code>HISTCONTROL</code> environment variable (Citation: Securing bash history). Also, make sure that the <code>HISTCONTROL</code> environment variable is set to “ignoredup” instead of “ignoreboth” or “ignorespace”.

## Properties

- id: T1148
- name: HISTCONTROL Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:40.291000+00:00
- type: course-of-action

## Mitigates Techniques


