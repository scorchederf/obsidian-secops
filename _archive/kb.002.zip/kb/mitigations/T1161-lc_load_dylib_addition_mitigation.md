---
id: T1161
name: LC_LOAD_DYLIB Addition Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:59.268000+00:00
type: course-of-action
---

# LC_LOAD_DYLIB Addition Mitigation

Enforce that all binaries be signed by the correct Apple Developer IDs, and whitelist applications via known hashes. Binaries can also be baselined for what dynamic libraries they require, and if an app requires a new dynamic library that wasn’t included as part of an update, it should be investigated.

## Properties

- id: T1161
- name: LC_LOAD_DYLIB Addition Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:59.268000+00:00
- type: course-of-action

## Mitigates Techniques


