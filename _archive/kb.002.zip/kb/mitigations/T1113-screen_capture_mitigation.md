---
id: T1113
name: Screen Capture Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:54.998000+00:00
type: course-of-action
---

# Screen Capture Mitigation

Blocking software based on screen capture functionality may be difficult, and there may be legitimate software that performs those actions. Instead, identify potentially malicious software that may have functionality to acquire screen captures, and audit and/or block it by using whitelisting (Citation: Beechey 2010) tools, like AppLocker, (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) or Software Restriction Policies (Citation: Corio 2008) where appropriate. (Citation: TechNet Applocker vs SRP)

## Properties

- id: T1113
- name: Screen Capture Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:54.998000+00:00
- type: course-of-action

## Mitigates Techniques


