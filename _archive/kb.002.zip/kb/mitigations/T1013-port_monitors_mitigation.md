---
id: T1013
name: Port Monitors Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:45.094000+00:00
type: course-of-action
---

# Port Monitors Mitigation

Identify and block potentially malicious software that may persist in this manner by using whitelisting (Citation: Beechey 2010) tools capable of monitoring DLL loads by processes running under SYSTEM permissions.

## Properties

- id: T1013
- name: Port Monitors Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:45.094000+00:00
- type: course-of-action

## Mitigates Techniques


