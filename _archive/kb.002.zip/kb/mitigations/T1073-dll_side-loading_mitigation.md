---
id: T1073
name: DLL Side-Loading Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:59.638000+00:00
type: course-of-action
---

# DLL Side-Loading Mitigation

Update software regularly. Install software in write-protected locations. Use the program sxstrace.exe that is included with Windows along with manual inspection to check manifest files for side-loading vulnerabilities in software.

## Properties

- id: T1073
- name: DLL Side-Loading Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:59.638000+00:00
- type: course-of-action

## Mitigates Techniques


