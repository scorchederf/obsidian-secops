---
id: T1174
name: Password Filter DLL Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:39.912000+00:00
type: course-of-action
---

# Password Filter DLL Mitigation

Ensure only valid password filters are registered. Filter DLLs must be present in Windows installation directory (<code>C:\Windows\System32\</code> by default) of a domain controller and/or local computer with a corresponding entry in <code>HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa\Notification Packages</code>. (Citation: Microsoft Install Password Filter n.d)

## Properties

- id: T1174
- name: Password Filter DLL Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:39.912000+00:00
- type: course-of-action

## Mitigates Techniques


