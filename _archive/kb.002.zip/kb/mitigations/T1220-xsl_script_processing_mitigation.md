---
id: T1220
name: XSL Script Processing Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:59.101000+00:00
type: course-of-action
---

# XSL Script Processing Mitigation

[Windows Management Instrumentation](https://attack.mitre.org/techniques/T1047) and/or msxsl.exe may or may not be used within a given environment. Disabling WMI may cause system instability and should be evaluated to assess the impact to a network. If msxsl.exe is unnecessary, then block its execution to prevent abuse by adversaries.

## Properties

- id: T1220
- name: XSL Script Processing Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:59.101000+00:00
- type: course-of-action

## Mitigates Techniques


