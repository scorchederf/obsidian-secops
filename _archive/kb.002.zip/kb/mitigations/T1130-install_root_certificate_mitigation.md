---
id: T1130
name: Install Root Certificate Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:45.811000+00:00
type: course-of-action
---

# Install Root Certificate Mitigation

HTTP Public Key Pinning (HPKP) is one method to mitigate potential man-in-the-middle situations where and adversary uses a mis-issued or fraudulent certificate to intercept encrypted communications by enforcing use of an expected certificate. (Citation: Wikipedia HPKP)

Windows Group Policy can be used to manage root certificates and the <code>Flags</code> value of <code>HKLM\SOFTWARE\Policies\Microsoft\SystemCertificates\Root\ProtectedRoots</code> can be set to 1 to prevent non-administrator users from making further root installations into their own HKCU certificate store. (Citation: SpectorOps Code Signing Dec 2017)

## Properties

- id: T1130
- name: Install Root Certificate Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:45.811000+00:00
- type: course-of-action

## Mitigates Techniques


