---
id: T1103
name: AppInit DLLs Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:42.128000+00:00
type: course-of-action
---

# AppInit DLLs Mitigation

Upgrade to Windows 8 or later and enable secure boot.

Identify and block potentially malicious software that may be executed through AppInit DLLs by using whitelisting (Citation: Beechey 2010) tools, like AppLocker, (Citation: Windows Commands JPCERT) (Citation: NSA MS AppLocker) that are capable of auditing and/or blocking unknown DLLs.

## Properties

- id: T1103
- name: AppInit DLLs Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:42.128000+00:00
- type: course-of-action

## Mitigates Techniques


