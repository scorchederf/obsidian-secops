---
id: T1498
name: Network Denial of Service Mitigation
created: 2019-04-19 18:46:47.964000+00:00
modified: 2025-04-18 17:59:57.486000+00:00
type: course-of-action
---

# Network Denial of Service Mitigation

When flood volumes exceed the capacity of the network connection being targeted, it is typically necessary to intercept the incoming traffic upstream to filter out the attack traffic from the legitimate traffic. Such defenses can be provided by the hosting Internet Service Provider (ISP) or by a 3rd party such as a Content Delivery Network (CDN) or providers specializing in DoS mitigations.(Citation: CERT-EU DDoS March 2017)

Depending on flood volume, on-premises filtering may be possible by blocking source addresses sourcing the attack, blocking ports that are being targeted, or blocking protocols being used for transport.(Citation: CERT-EU DDoS March 2017)

As immediate response may require rapid engagement of 3rd parties, analyze the risk associated to critical resources being affected by Network DoS attacks and create a disaster recovery plan/business continuity plan to respond to incidents.(Citation: CERT-EU DDoS March 2017)

## Properties

- id: T1498
- name: Network Denial of Service Mitigation
- created: 2019-04-19 18:46:47.964000+00:00
- modified: 2025-04-18 17:59:57.486000+00:00
- type: course-of-action

## Mitigates Techniques


