---
id: T1142
name: Keychain Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:56.074000+00:00
type: course-of-action
---

# Keychain Mitigation

The password for the user's login keychain can be changed from the user's login password. This increases the complexity for an adversary because they need to know an additional password.

## Properties

- id: T1142
- name: Keychain Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:56.074000+00:00
- type: course-of-action

## Mitigates Techniques


