---
id: T1169
name: Sudo Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:45.997000+00:00
type: course-of-action
---

# Sudo Mitigation

The sudoers file should be strictly edited such that passwords are always required and that users can’t spawn risky processes as users with higher privilege. By requiring a password, even if an adversary can get terminal access, they must know the password to run anything in the sudoers file.

## Properties

- id: T1169
- name: Sudo Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:45.997000+00:00
- type: course-of-action

## Mitigates Techniques


