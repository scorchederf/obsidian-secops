---
id: T1079
name: Multilayer Encryption Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:46.167000+00:00
type: course-of-action
---

# Multilayer Encryption Mitigation

Network intrusion detection and prevention systems that use network signatures to identify traffic for specific adversary malware can be used to mitigate activity at the network level. Use of encryption protocols may make typical network-based C2 detection more difficult due to a reduced ability to signature the traffic. Prior knowledge of adversary C2 infrastructure may be useful for domain and IP address blocking, but will likely not be an effective long-term solution because adversaries can change infrastructure often. (Citation: University of Birmingham C2)

## Properties

- id: T1079
- name: Multilayer Encryption Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:46.167000+00:00
- type: course-of-action

## Mitigates Techniques


