---
id: T1008
name: Fallback Channels Mitigation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-18 17:59:54.798000+00:00
type: course-of-action
---

# Fallback Channels Mitigation

Network intrusion detection and prevention systems that use network signatures to identify traffic for specific adversary malware can be used to mitigate activity at the network level. Signatures are often for unique indicators within protocols and may be based on the specific protocol used by a particular adversary or tool, and will likely be different across various malware families and versions. Adversaries will likely change tool C2 signatures over time or construct protocols in such a way as to avoid detection by common defensive tools. (Citation: University of Birmingham C2)

## Properties

- id: T1008
- name: Fallback Channels Mitigation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-18 17:59:54.798000+00:00
- type: course-of-action

## Mitigates Techniques


