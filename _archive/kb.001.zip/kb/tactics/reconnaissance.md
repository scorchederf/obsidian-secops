---
id: x-mitre-tactic--daa4cbb1-b4f4-4723-a824-7f1efd6e0592
name: Reconnaissance
created: 2020-10-02 14:48:41.809000+00:00
modified: 2025-04-25 14:45:36.201000+00:00
type: x-mitre-tactic
x_mitre_version: 1.0
x_mitre_domains: enterprise-attack
---

# Reconnaissance

The adversary is trying to gather information they can use to plan future operations.

Reconnaissance consists of techniques that involve adversaries actively or passively gathering information that can be used to support targeting. Such information may include details of the victim organization, infrastructure, or staff/personnel. This information can be leveraged by the adversary to aid in other phases of the adversary lifecycle, such as using gathered information to plan and execute Initial Access, to scope and prioritize post-compromise objectives, or to drive and lead further Reconnaissance efforts.

## Properties

- id: x-mitre-tactic--daa4cbb1-b4f4-4723-a824-7f1efd6e0592
- name: Reconnaissance
- created: 2020-10-02 14:48:41.809000+00:00
- modified: 2025-04-25 14:45:36.201000+00:00
- type: x-mitre-tactic
- x_mitre_version: 1.0
- x_mitre_domains: enterprise-attack

## Related Techniques

- [[T1589-gather_victim_identity_information|T1589: Gather Victim Identity Information]]
    - [[T1589.001-credentials|T1589.001: Credentials]]
    - [[T1589.002-email_addresses|T1589.002: Email Addresses]]
    - [[T1589.003-employee_names|T1589.003: Employee Names]]
- [[T1590-gather_victim_network_information|T1590: Gather Victim Network Information]]
    - [[T1590.001-domain_properties|T1590.001: Domain Properties]]
    - [[T1590.002-dns|T1590.002: DNS]]
    - [[T1590.003-network_trust_dependencies|T1590.003: Network Trust Dependencies]]
    - [[T1590.004-network_topology|T1590.004: Network Topology]]
    - [[T1590.005-ip_addresses|T1590.005: IP Addresses]]
    - [[T1590.006-network_security_appliances|T1590.006: Network Security Appliances]]
- [[T1591-gather_victim_org_information|T1591: Gather Victim Org Information]]
    - [[T1591.001-determine_physical_locations|T1591.001: Determine Physical Locations]]
    - [[T1591.002-business_relationships|T1591.002: Business Relationships]]
    - [[T1591.003-identify_business_tempo|T1591.003: Identify Business Tempo]]
    - [[T1591.004-identify_roles|T1591.004: Identify Roles]]
- [[T1592-gather_victim_host_information|T1592: Gather Victim Host Information]]
    - [[T1592.001-hardware|T1592.001: Hardware]]
    - [[T1592.002-software|T1592.002: Software]]
    - [[T1592.003-firmware|T1592.003: Firmware]]
    - [[T1592.004-client_configurations|T1592.004: Client Configurations]]
- [[T1593-search_open_websites_domains|T1593: Search Open Websites/Domains]]
    - [[T1593.001-social_media|T1593.001: Social Media]]
    - [[T1593.002-search_engines|T1593.002: Search Engines]]
    - [[T1593.003-code_repositories|T1593.003: Code Repositories]]
- [[T1594-search_victim-owned_websites|T1594: Search Victim-Owned Websites]]
- [[T1595-active_scanning|T1595: Active Scanning]]
    - [[T1595.001-scanning_ip_blocks|T1595.001: Scanning IP Blocks]]
    - [[T1595.002-vulnerability_scanning|T1595.002: Vulnerability Scanning]]
    - [[T1595.003-wordlist_scanning|T1595.003: Wordlist Scanning]]
- [[T1596-search_open_technical_databases|T1596: Search Open Technical Databases]]
    - [[T1596.001-dns_passive_dns|T1596.001: DNS/Passive DNS]]
    - [[T1596.002-whois|T1596.002: WHOIS]]
    - [[T1596.003-digital_certificates|T1596.003: Digital Certificates]]
    - [[T1596.004-cdns|T1596.004: CDNs]]
    - [[T1596.005-scan_databases|T1596.005: Scan Databases]]
- [[T1597-search_closed_sources|T1597: Search Closed Sources]]
    - [[T1597.001-threat_intel_vendors|T1597.001: Threat Intel Vendors]]
    - [[T1597.002-purchase_technical_data|T1597.002: Purchase Technical Data]]
- [[T1598-phishing_for_information|T1598: Phishing for Information]]
    - [[T1598.001-spearphishing_service|T1598.001: Spearphishing Service]]
    - [[T1598.002-spearphishing_attachment|T1598.002: Spearphishing Attachment]]
    - [[T1598.003-spearphishing_link|T1598.003: Spearphishing Link]]
    - [[T1598.004-spearphishing_voice|T1598.004: Spearphishing Voice]]
- [[T1681-search_threat_vendor_data|T1681: Search Threat Vendor Data]]
