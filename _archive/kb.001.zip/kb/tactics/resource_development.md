---
id: x-mitre-tactic--d679bca2-e57d-4935-8650-8031c87a4400
name: Resource Development
created: 2020-09-30 16:11:59.650000+00:00
modified: 2025-04-25 14:45:35.841000+00:00
type: x-mitre-tactic
x_mitre_version: 1.0
x_mitre_domains: enterprise-attack
---

# Resource Development

The adversary is trying to establish resources they can use to support operations.

Resource Development consists of techniques that involve adversaries creating, purchasing, or compromising/stealing resources that can be used to support targeting. Such resources include infrastructure, accounts, or capabilities. These resources can be leveraged by the adversary to aid in other phases of the adversary lifecycle, such as using purchased domains to support Command and Control, email accounts for phishing as a part of Initial Access, or stealing code signing certificates to help with Defense Evasion.

## Properties

- id: x-mitre-tactic--d679bca2-e57d-4935-8650-8031c87a4400
- name: Resource Development
- created: 2020-09-30 16:11:59.650000+00:00
- modified: 2025-04-25 14:45:35.841000+00:00
- type: x-mitre-tactic
- x_mitre_version: 1.0
- x_mitre_domains: enterprise-attack

## Related Techniques

- [[T1583-acquire_infrastructure|T1583: Acquire Infrastructure]]
    - [[T1583.001-domains|T1583.001: Domains]]
    - [[T1583.002-dns_server|T1583.002: DNS Server]]
    - [[T1583.003-virtual_private_server|T1583.003: Virtual Private Server]]
    - [[T1583.004-server|T1583.004: Server]]
    - [[T1583.005-botnet|T1583.005: Botnet]]
    - [[T1583.006-web_services|T1583.006: Web Services]]
    - [[T1583.007-serverless|T1583.007: Serverless]]
    - [[T1583.008-malvertising|T1583.008: Malvertising]]
- [[T1584-compromise_infrastructure|T1584: Compromise Infrastructure]]
    - [[T1584.001-domains|T1584.001: Domains]]
    - [[T1584.002-dns_server|T1584.002: DNS Server]]
    - [[T1584.003-virtual_private_server|T1584.003: Virtual Private Server]]
    - [[T1584.004-server|T1584.004: Server]]
    - [[T1584.005-botnet|T1584.005: Botnet]]
    - [[T1584.006-web_services|T1584.006: Web Services]]
    - [[T1584.007-serverless|T1584.007: Serverless]]
    - [[T1584.008-network_devices|T1584.008: Network Devices]]
- [[T1585-establish_accounts|T1585: Establish Accounts]]
    - [[T1585.001-social_media_accounts|T1585.001: Social Media Accounts]]
    - [[T1585.002-email_accounts|T1585.002: Email Accounts]]
    - [[T1585.003-cloud_accounts|T1585.003: Cloud Accounts]]
- [[T1586-compromise_accounts|T1586: Compromise Accounts]]
    - [[T1586.001-social_media_accounts|T1586.001: Social Media Accounts]]
    - [[T1586.002-email_accounts|T1586.002: Email Accounts]]
    - [[T1586.003-cloud_accounts|T1586.003: Cloud Accounts]]
- [[T1587-develop_capabilities|T1587: Develop Capabilities]]
    - [[T1587.001-malware|T1587.001: Malware]]
    - [[T1587.002-code_signing_certificates|T1587.002: Code Signing Certificates]]
    - [[T1587.003-digital_certificates|T1587.003: Digital Certificates]]
    - [[T1587.004-exploits|T1587.004: Exploits]]
- [[T1588-obtain_capabilities|T1588: Obtain Capabilities]]
    - [[T1588.001-malware|T1588.001: Malware]]
    - [[T1588.002-tool|T1588.002: Tool]]
    - [[T1588.003-code_signing_certificates|T1588.003: Code Signing Certificates]]
    - [[T1588.004-digital_certificates|T1588.004: Digital Certificates]]
    - [[T1588.005-exploits|T1588.005: Exploits]]
    - [[T1588.006-vulnerabilities|T1588.006: Vulnerabilities]]
    - [[T1588.007-artificial_intelligence|T1588.007: Artificial Intelligence]]
- [[T1608-stage_capabilities|T1608: Stage Capabilities]]
    - [[T1608.001-upload_malware|T1608.001: Upload Malware]]
    - [[T1608.002-upload_tool|T1608.002: Upload Tool]]
    - [[T1608.003-install_digital_certificate|T1608.003: Install Digital Certificate]]
    - [[T1608.004-drive-by_target|T1608.004: Drive-by Target]]
    - [[T1608.005-link_target|T1608.005: Link Target]]
    - [[T1608.006-seo_poisoning|T1608.006: SEO Poisoning]]
- [[T1650-acquire_access|T1650: Acquire Access]]
