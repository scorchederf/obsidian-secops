---
id: x-mitre-tactic--5e29b093-294e-49e9-a803-dab3d73b77dd
name: Privilege Escalation
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-25 14:45:33.853000+00:00
type: x-mitre-tactic
x_mitre_version: 1.0
x_mitre_domains: enterprise-attack
---

# Privilege Escalation

The adversary is trying to gain higher-level permissions.

Privilege Escalation consists of techniques that adversaries use to gain higher-level permissions on a system or network. Adversaries can often enter and explore a network with unprivileged access but require elevated permissions to follow through on their objectives. Common approaches are to take advantage of system weaknesses, misconfigurations, and vulnerabilities. Examples of elevated access include: 

* SYSTEM/root level
* local administrator
* user account with admin-like access 
* user accounts with access to specific system or perform specific function

These techniques often overlap with Persistence techniques, as OS features that let an adversary persist can execute in an elevated context.  

## Properties

- id: x-mitre-tactic--5e29b093-294e-49e9-a803-dab3d73b77dd
- name: Privilege Escalation
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-25 14:45:33.853000+00:00
- type: x-mitre-tactic
- x_mitre_version: 1.0
- x_mitre_domains: enterprise-attack

## Related Techniques

- [[T1013-port_monitors|T1013: Port Monitors]]
- [[T1015-accessibility_features|T1015: Accessibility Features]]
- [[T1034-path_interception|T1034: Path Interception]]
- [[T1037-boot_or_logon_initialization_scripts|T1037: Boot or Logon Initialization Scripts]]
    - [[T1037.001-logon_script_(windows)|T1037.001: Logon Script (Windows)]]
    - [[T1037.002-login_hook|T1037.002: Login Hook]]
    - [[T1037.003-network_logon_script|T1037.003: Network Logon Script]]
    - [[T1037.004-rc_scripts|T1037.004: RC Scripts]]
    - [[T1037.005-startup_items|T1037.005: Startup Items]]
- [[T1038-dll_search_order_hijacking|T1038: DLL Search Order Hijacking]]
- [[T1044-file_system_permissions_weakness|T1044: File System Permissions Weakness]]
- [[T1050-new_service|T1050: New Service]]
- [[T1053-scheduled_task_job|T1053: Scheduled Task/Job]]
    - [[T1053.002-at|T1053.002: At]]
    - [[T1053.003-cron|T1053.003: Cron]]
    - [[T1053.005-scheduled_task|T1053.005: Scheduled Task]]
    - [[T1053.006-systemd_timers|T1053.006: Systemd Timers]]
    - [[T1053.007-container_orchestration_job|T1053.007: Container Orchestration Job]]
- [[T1055-process_injection|T1055: Process Injection]]
    - [[T1055.001-dynamic-link_library_injection|T1055.001: Dynamic-link Library Injection]]
    - [[T1055.002-portable_executable_injection|T1055.002: Portable Executable Injection]]
    - [[T1055.003-thread_execution_hijacking|T1055.003: Thread Execution Hijacking]]
    - [[T1055.004-asynchronous_procedure_call|T1055.004: Asynchronous Procedure Call]]
    - [[T1055.005-thread_local_storage|T1055.005: Thread Local Storage]]
    - [[T1055.008-ptrace_system_calls|T1055.008: Ptrace System Calls]]
    - [[T1055.009-proc_memory|T1055.009: Proc Memory]]
    - [[T1055.011-extra_window_memory_injection|T1055.011: Extra Window Memory Injection]]
    - [[T1055.012-process_hollowing|T1055.012: Process Hollowing]]
    - [[T1055.013-process_doppelgänging|T1055.013: Process Doppelgänging]]
    - [[T1055.014-vdso_hijacking|T1055.014: VDSO Hijacking]]
    - [[T1055.015-listplanting|T1055.015: ListPlanting]]
- [[T1058-service_registry_permissions_weakness|T1058: Service Registry Permissions Weakness]]
- [[T1068-exploitation_for_privilege_escalation|T1068: Exploitation for Privilege Escalation]]
- [[T1078-valid_accounts|T1078: Valid Accounts]]
    - [[T1078.001-default_accounts|T1078.001: Default Accounts]]
    - [[T1078.002-domain_accounts|T1078.002: Domain Accounts]]
    - [[T1078.003-local_accounts|T1078.003: Local Accounts]]
    - [[T1078.004-cloud_accounts|T1078.004: Cloud Accounts]]
- [[T1088-bypass_user_account_control|T1088: Bypass User Account Control]]
- [[T1098-account_manipulation|T1098: Account Manipulation]]
    - [[T1098.001-additional_cloud_credentials|T1098.001: Additional Cloud Credentials]]
    - [[T1098.002-additional_email_delegate_permissions|T1098.002: Additional Email Delegate Permissions]]
    - [[T1098.003-additional_cloud_roles|T1098.003: Additional Cloud Roles]]
    - [[T1098.004-ssh_authorized_keys|T1098.004: SSH Authorized Keys]]
    - [[T1098.005-device_registration|T1098.005: Device Registration]]
    - [[T1098.006-additional_container_cluster_roles|T1098.006: Additional Container Cluster Roles]]
    - [[T1098.007-additional_local_or_domain_groups|T1098.007: Additional Local or Domain Groups]]
- [[T1100-web_shell|T1100: Web Shell]]
- [[T1103-appinit_dlls|T1103: AppInit DLLs]]
- [[T1134-access_token_manipulation|T1134: Access Token Manipulation]]
    - [[T1134.001-token_impersonation_theft|T1134.001: Token Impersonation/Theft]]
    - [[T1134.002-create_process_with_token|T1134.002: Create Process with Token]]
    - [[T1134.003-make_and_impersonate_token|T1134.003: Make and Impersonate Token]]
    - [[T1134.004-parent_pid_spoofing|T1134.004: Parent PID Spoofing]]
    - [[T1134.005-sid-history_injection|T1134.005: SID-History Injection]]
- [[T1138-application_shimming|T1138: Application Shimming]]
- [[T1150-plist_modification|T1150: Plist Modification]]
- [[T1157-dylib_hijacking|T1157: Dylib Hijacking]]
- [[T1160-launch_daemon|T1160: Launch Daemon]]
- [[T1165-startup_items|T1165: Startup Items]]
- [[T1166-setuid_and_setgid|T1166: Setuid and Setgid]]
- [[T1169-sudo|T1169: Sudo]]
- [[T1178-sid-history_injection|T1178: SID-History Injection]]
- [[T1179-hooking|T1179: Hooking]]
- [[T1181-extra_window_memory_injection|T1181: Extra Window Memory Injection]]
- [[T1182-appcert_dlls|T1182: AppCert DLLs]]
- [[T1183-image_file_execution_options_injection|T1183: Image File Execution Options Injection]]
- [[T1206-sudo_caching|T1206: Sudo Caching]]
- [[T1484-domain_or_tenant_policy_modification|T1484: Domain or Tenant Policy Modification]]
    - [[T1484.001-group_policy_modification|T1484.001: Group Policy Modification]]
    - [[T1484.002-trust_modification|T1484.002: Trust Modification]]
- [[T1502-parent_pid_spoofing|T1502: Parent PID Spoofing]]
- [[T1504-powershell_profile|T1504: PowerShell Profile]]
- [[T1514-elevated_execution_with_prompt|T1514: Elevated Execution with Prompt]]
- [[T1519-emond|T1519: Emond]]
- [[T1543-create_or_modify_system_process|T1543: Create or Modify System Process]]
    - [[T1543.001-launch_agent|T1543.001: Launch Agent]]
    - [[T1543.002-systemd_service|T1543.002: Systemd Service]]
    - [[T1543.003-windows_service|T1543.003: Windows Service]]
    - [[T1543.004-launch_daemon|T1543.004: Launch Daemon]]
    - [[T1543.005-container_service|T1543.005: Container Service]]
- [[T1546-event_triggered_execution|T1546: Event Triggered Execution]]
    - [[T1546.001-change_default_file_association|T1546.001: Change Default File Association]]
    - [[T1546.002-screensaver|T1546.002: Screensaver]]
    - [[T1546.003-windows_management_instrumentation_event_subscription|T1546.003: Windows Management Instrumentation Event Subscription]]
    - [[T1546.004-unix_shell_configuration_modification|T1546.004: Unix Shell Configuration Modification]]
    - [[T1546.005-trap|T1546.005: Trap]]
    - [[T1546.006-lc_load_dylib_addition|T1546.006: LC_LOAD_DYLIB Addition]]
    - [[T1546.007-netsh_helper_dll|T1546.007: Netsh Helper DLL]]
    - [[T1546.008-accessibility_features|T1546.008: Accessibility Features]]
    - [[T1546.009-appcert_dlls|T1546.009: AppCert DLLs]]
    - [[T1546.010-appinit_dlls|T1546.010: AppInit DLLs]]
    - [[T1546.011-application_shimming|T1546.011: Application Shimming]]
    - [[T1546.012-image_file_execution_options_injection|T1546.012: Image File Execution Options Injection]]
    - [[T1546.013-powershell_profile|T1546.013: PowerShell Profile]]
    - [[T1546.014-emond|T1546.014: Emond]]
    - [[T1546.015-component_object_model_hijacking|T1546.015: Component Object Model Hijacking]]
    - [[T1546.016-installer_packages|T1546.016: Installer Packages]]
    - [[T1546.017-udev_rules|T1546.017: Udev Rules]]
    - [[T1546.018-python_startup_hooks|T1546.018: Python Startup Hooks]]
- [[T1547-boot_or_logon_autostart_execution|T1547: Boot or Logon Autostart Execution]]
    - [[T1547.001-registry_run_keys___startup_folder|T1547.001: Registry Run Keys / Startup Folder]]
    - [[T1547.002-authentication_package|T1547.002: Authentication Package]]
    - [[T1547.003-time_providers|T1547.003: Time Providers]]
    - [[T1547.004-winlogon_helper_dll|T1547.004: Winlogon Helper DLL]]
    - [[T1547.005-security_support_provider|T1547.005: Security Support Provider]]
    - [[T1547.006-kernel_modules_and_extensions|T1547.006: Kernel Modules and Extensions]]
    - [[T1547.007-re-opened_applications|T1547.007: Re-opened Applications]]
    - [[T1547.008-lsass_driver|T1547.008: LSASS Driver]]
    - [[T1547.009-shortcut_modification|T1547.009: Shortcut Modification]]
    - [[T1547.010-port_monitors|T1547.010: Port Monitors]]
    - [[T1547.012-print_processors|T1547.012: Print Processors]]
    - [[T1547.013-xdg_autostart_entries|T1547.013: XDG Autostart Entries]]
    - [[T1547.014-active_setup|T1547.014: Active Setup]]
    - [[T1547.015-login_items|T1547.015: Login Items]]
- [[T1548-abuse_elevation_control_mechanism|T1548: Abuse Elevation Control Mechanism]]
    - [[T1548.001-setuid_and_setgid|T1548.001: Setuid and Setgid]]
    - [[T1548.002-bypass_user_account_control|T1548.002: Bypass User Account Control]]
    - [[T1548.003-sudo_and_sudo_caching|T1548.003: Sudo and Sudo Caching]]
    - [[T1548.004-elevated_execution_with_prompt|T1548.004: Elevated Execution with Prompt]]
    - [[T1548.005-temporary_elevated_cloud_access|T1548.005: Temporary Elevated Cloud Access]]
    - [[T1548.006-tcc_manipulation|T1548.006: TCC Manipulation]]
- [[T1574-hijack_execution_flow|T1574: Hijack Execution Flow]]
    - [[T1574.001-dll|T1574.001: DLL]]
    - [[T1574.004-dylib_hijacking|T1574.004: Dylib Hijacking]]
    - [[T1574.005-executable_installer_file_permissions_weakness|T1574.005: Executable Installer File Permissions Weakness]]
    - [[T1574.006-dynamic_linker_hijacking|T1574.006: Dynamic Linker Hijacking]]
    - [[T1574.007-path_interception_by_path_environment_variable|T1574.007: Path Interception by PATH Environment Variable]]
    - [[T1574.008-path_interception_by_search_order_hijacking|T1574.008: Path Interception by Search Order Hijacking]]
    - [[T1574.009-path_interception_by_unquoted_path|T1574.009: Path Interception by Unquoted Path]]
    - [[T1574.010-services_file_permissions_weakness|T1574.010: Services File Permissions Weakness]]
    - [[T1574.011-services_registry_permissions_weakness|T1574.011: Services Registry Permissions Weakness]]
    - [[T1574.012-cor_profiler|T1574.012: COR_PROFILER]]
    - [[T1574.013-kernelcallbacktable|T1574.013: KernelCallbackTable]]
    - [[T1574.014-appdomainmanager|T1574.014: AppDomainManager]]
- [[T1611-escape_to_host|T1611: Escape to Host]]
