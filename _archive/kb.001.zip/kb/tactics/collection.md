---
id: x-mitre-tactic--d108ce10-2419-4cf9-a774-46161d6c6cfe
name: Collection
created: 2018-10-17 00:14:20.652000+00:00
modified: 2024-09-05 18:27:09.070000+00:00
type: x-mitre-tactic
x_mitre_version: 1.1
x_mitre_domains: enterprise-attack
---

# Collection

The adversary is trying to gather data of interest to their goal.

Collection consists of techniques adversaries may use to gather information and the sources information is collected from that are relevant to following through on the adversary's objectives. Frequently, the next goal after collecting data is to either steal (exfiltrate) the data or to use the data to gain more information about the target environment. Common target sources include various drive types, browsers, audio, video, and email. Common collection methods include capturing screenshots and keyboard input.

## Properties

- id: x-mitre-tactic--d108ce10-2419-4cf9-a774-46161d6c6cfe
- name: Collection
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2024-09-05 18:27:09.070000+00:00
- type: x-mitre-tactic
- x_mitre_version: 1.1
- x_mitre_domains: enterprise-attack

## Related Techniques

- [[T1005-data_from_local_system|T1005: Data from Local System]]
- [[T1025-data_from_removable_media|T1025: Data from Removable Media]]
- [[T1039-data_from_network_shared_drive|T1039: Data from Network Shared Drive]]
- [[T1056-input_capture|T1056: Input Capture]]
    - [[T1056.001-keylogging|T1056.001: Keylogging]]
    - [[T1056.002-gui_input_capture|T1056.002: GUI Input Capture]]
    - [[T1056.003-web_portal_capture|T1056.003: Web Portal Capture]]
    - [[T1056.004-credential_api_hooking|T1056.004: Credential API Hooking]]
- [[T1074-data_staged|T1074: Data Staged]]
    - [[T1074.001-local_data_staging|T1074.001: Local Data Staging]]
    - [[T1074.002-remote_data_staging|T1074.002: Remote Data Staging]]
- [[T1113-screen_capture|T1113: Screen Capture]]
- [[T1114-email_collection|T1114: Email Collection]]
    - [[T1114.001-local_email_collection|T1114.001: Local Email Collection]]
    - [[T1114.002-remote_email_collection|T1114.002: Remote Email Collection]]
    - [[T1114.003-email_forwarding_rule|T1114.003: Email Forwarding Rule]]
- [[T1115-clipboard_data|T1115: Clipboard Data]]
- [[T1119-automated_collection|T1119: Automated Collection]]
- [[T1123-audio_capture|T1123: Audio Capture]]
- [[T1125-video_capture|T1125: Video Capture]]
- [[T1185-browser_session_hijacking|T1185: Browser Session Hijacking]]
- [[T1213-data_from_information_repositories|T1213: Data from Information Repositories]]
    - [[T1213.001-confluence|T1213.001: Confluence]]
    - [[T1213.002-sharepoint|T1213.002: Sharepoint]]
    - [[T1213.003-code_repositories|T1213.003: Code Repositories]]
    - [[T1213.004-customer_relationship_management_software|T1213.004: Customer Relationship Management Software]]
    - [[T1213.005-messaging_applications|T1213.005: Messaging Applications]]
    - [[T1213.006-databases|T1213.006: Databases]]
- [[T1530-data_from_cloud_storage|T1530: Data from Cloud Storage]]
- [[T1557-adversary-in-the-middle|T1557: Adversary-in-the-Middle]]
    - [[T1557.001-llmnr_nbt-ns_poisoning_and_smb_relay|T1557.001: LLMNR/NBT-NS Poisoning and SMB Relay]]
    - [[T1557.002-arp_cache_poisoning|T1557.002: ARP Cache Poisoning]]
    - [[T1557.003-dhcp_spoofing|T1557.003: DHCP Spoofing]]
    - [[T1557.004-evil_twin|T1557.004: Evil Twin]]
- [[T1560-archive_collected_data|T1560: Archive Collected Data]]
    - [[T1560.001-archive_via_utility|T1560.001: Archive via Utility]]
    - [[T1560.002-archive_via_library|T1560.002: Archive via Library]]
    - [[T1560.003-archive_via_custom_method|T1560.003: Archive via Custom Method]]
- [[T1602-data_from_configuration_repository|T1602: Data from Configuration Repository]]
    - [[T1602.001-snmp_(mib_dump)|T1602.001: SNMP (MIB Dump)]]
    - [[T1602.002-network_device_configuration_dump|T1602.002: Network Device Configuration Dump]]
