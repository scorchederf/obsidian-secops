---
id: x-mitre-tactic--2558fd61-8c75-4730-94c4-11926db2a263
name: Credential Access
created: 2018-10-17 00:14:20.652000+00:00
modified: 2025-04-25 14:45:32.408000+00:00
type: x-mitre-tactic
x_mitre_version: 1.0
x_mitre_domains: enterprise-attack
---

# Credential Access

The adversary is trying to steal account names and passwords.

Credential Access consists of techniques for stealing credentials like account names and passwords. Techniques used to get credentials include keylogging or credential dumping. Using legitimate credentials can give adversaries access to systems, make them harder to detect, and provide the opportunity to create more accounts to help achieve their goals.

## Properties

- id: x-mitre-tactic--2558fd61-8c75-4730-94c4-11926db2a263
- name: Credential Access
- created: 2018-10-17 00:14:20.652000+00:00
- modified: 2025-04-25 14:45:32.408000+00:00
- type: x-mitre-tactic
- x_mitre_version: 1.0
- x_mitre_domains: enterprise-attack

## Related Techniques

- [[T1003-os_credential_dumping|T1003: OS Credential Dumping]]
    - [[T1003.001-lsass_memory|T1003.001: LSASS Memory]]
    - [[T1003.002-security_account_manager|T1003.002: Security Account Manager]]
    - [[T1003.003-ntds|T1003.003: NTDS]]
    - [[T1003.004-lsa_secrets|T1003.004: LSA Secrets]]
    - [[T1003.005-cached_domain_credentials|T1003.005: Cached Domain Credentials]]
    - [[T1003.006-dcsync|T1003.006: DCSync]]
    - [[T1003.007-proc_filesystem|T1003.007: Proc Filesystem]]
    - [[T1003.008-_etc_passwd_and__etc_shadow|T1003.008: /etc/passwd and /etc/shadow]]
- [[T1040-network_sniffing|T1040: Network Sniffing]]
- [[T1056-input_capture|T1056: Input Capture]]
    - [[T1056.001-keylogging|T1056.001: Keylogging]]
    - [[T1056.002-gui_input_capture|T1056.002: GUI Input Capture]]
    - [[T1056.003-web_portal_capture|T1056.003: Web Portal Capture]]
    - [[T1056.004-credential_api_hooking|T1056.004: Credential API Hooking]]
- [[T1081-credentials_in_files|T1081: Credentials in Files]]
- [[T1110-brute_force|T1110: Brute Force]]
    - [[T1110.001-password_guessing|T1110.001: Password Guessing]]
    - [[T1110.002-password_cracking|T1110.002: Password Cracking]]
    - [[T1110.003-password_spraying|T1110.003: Password Spraying]]
    - [[T1110.004-credential_stuffing|T1110.004: Credential Stuffing]]
- [[T1111-multi-factor_authentication_interception|T1111: Multi-Factor Authentication Interception]]
- [[T1139-bash_history|T1139: Bash History]]
- [[T1141-input_prompt|T1141: Input Prompt]]
- [[T1142-keychain|T1142: Keychain]]
- [[T1145-private_keys|T1145: Private Keys]]
- [[T1167-securityd_memory|T1167: Securityd Memory]]
- [[T1171-llmnr_nbt-ns_poisoning_and_relay|T1171: LLMNR/NBT-NS Poisoning and Relay]]
- [[T1174-password_filter_dll|T1174: Password Filter DLL]]
- [[T1179-hooking|T1179: Hooking]]
- [[T1187-forced_authentication|T1187: Forced Authentication]]
- [[T1208-kerberoasting|T1208: Kerberoasting]]
- [[T1212-exploitation_for_credential_access|T1212: Exploitation for Credential Access]]
- [[T1214-credentials_in_registry|T1214: Credentials in Registry]]
- [[T1503-credentials_from_web_browsers|T1503: Credentials from Web Browsers]]
- [[T1522-cloud_instance_metadata_api|T1522: Cloud Instance Metadata API]]
- [[T1528-steal_application_access_token|T1528: Steal Application Access Token]]
- [[T1539-steal_web_session_cookie|T1539: Steal Web Session Cookie]]
- [[T1552-unsecured_credentials|T1552: Unsecured Credentials]]
    - [[T1552.001-credentials_in_files|T1552.001: Credentials In Files]]
    - [[T1552.002-credentials_in_registry|T1552.002: Credentials in Registry]]
    - [[T1552.003-shell_history|T1552.003: Shell History]]
    - [[T1552.004-private_keys|T1552.004: Private Keys]]
    - [[T1552.005-cloud_instance_metadata_api|T1552.005: Cloud Instance Metadata API]]
    - [[T1552.006-group_policy_preferences|T1552.006: Group Policy Preferences]]
    - [[T1552.007-container_api|T1552.007: Container API]]
    - [[T1552.008-chat_messages|T1552.008: Chat Messages]]
- [[T1555-credentials_from_password_stores|T1555: Credentials from Password Stores]]
    - [[T1555.001-keychain|T1555.001: Keychain]]
    - [[T1555.002-securityd_memory|T1555.002: Securityd Memory]]
    - [[T1555.003-credentials_from_web_browsers|T1555.003: Credentials from Web Browsers]]
    - [[T1555.004-windows_credential_manager|T1555.004: Windows Credential Manager]]
    - [[T1555.005-password_managers|T1555.005: Password Managers]]
    - [[T1555.006-cloud_secrets_management_stores|T1555.006: Cloud Secrets Management Stores]]
- [[T1556-modify_authentication_process|T1556: Modify Authentication Process]]
    - [[T1556.001-domain_controller_authentication|T1556.001: Domain Controller Authentication]]
    - [[T1556.002-password_filter_dll|T1556.002: Password Filter DLL]]
    - [[T1556.003-pluggable_authentication_modules|T1556.003: Pluggable Authentication Modules]]
    - [[T1556.004-network_device_authentication|T1556.004: Network Device Authentication]]
    - [[T1556.005-reversible_encryption|T1556.005: Reversible Encryption]]
    - [[T1556.006-multi-factor_authentication|T1556.006: Multi-Factor Authentication]]
    - [[T1556.007-hybrid_identity|T1556.007: Hybrid Identity]]
    - [[T1556.008-network_provider_dll|T1556.008: Network Provider DLL]]
    - [[T1556.009-conditional_access_policies|T1556.009: Conditional Access Policies]]
- [[T1557-adversary-in-the-middle|T1557: Adversary-in-the-Middle]]
    - [[T1557.001-llmnr_nbt-ns_poisoning_and_smb_relay|T1557.001: LLMNR/NBT-NS Poisoning and SMB Relay]]
    - [[T1557.002-arp_cache_poisoning|T1557.002: ARP Cache Poisoning]]
    - [[T1557.003-dhcp_spoofing|T1557.003: DHCP Spoofing]]
    - [[T1557.004-evil_twin|T1557.004: Evil Twin]]
- [[T1558-steal_or_forge_kerberos_tickets|T1558: Steal or Forge Kerberos Tickets]]
    - [[T1558.001-golden_ticket|T1558.001: Golden Ticket]]
    - [[T1558.002-silver_ticket|T1558.002: Silver Ticket]]
    - [[T1558.003-kerberoasting|T1558.003: Kerberoasting]]
    - [[T1558.004-as-rep_roasting|T1558.004: AS-REP Roasting]]
    - [[T1558.005-ccache_files|T1558.005: Ccache Files]]
- [[T1606-forge_web_credentials|T1606: Forge Web Credentials]]
    - [[T1606.001-web_cookies|T1606.001: Web Cookies]]
    - [[T1606.002-saml_tokens|T1606.002: SAML Tokens]]
- [[T1621-multi-factor_authentication_request_generation|T1621: Multi-Factor Authentication Request Generation]]
- [[T1649-steal_or_forge_authentication_certificates|T1649: Steal or Forge Authentication Certificates]]
